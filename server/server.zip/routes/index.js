const express = require("express");
const router = express.Router();

let routes = (app) => {

  app.use(router);
};

module.exports = routes;
