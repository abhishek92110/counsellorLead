  'Become a Software Tester Aug',
  'API Automation Testing Aug',
  'Become a Software Tester July',
  'Digital Marketing July Placement',
  'Tailored full stack developer course 22 june Campaign',
  'Tailored api automation campaign 06/20/2024 Campaign',
  'Tailored front end course  campaign 06/14/20 Campaign',
  'Become a Business Analytics',
  'Tailored2 Data Science leads campaign 05/15/2024 29 Campaign',
  'Tailored2 leads software Testingcampaign 05/15/2024 Campaign',
  'Tailored data science 20k campaign 05/14/2024 Campaign',
  'Web Development New Session',
  'Data Science New Sessions 2 - Copy',
  'Data Science New Sessions 2',
  'Digital Marketing Jan Campaign',
  'Best Software Testing Training',
  'Full Stack Course',
  'Data Scientist  Campaign',
  'Software Testing Oct Campaign',
  'Full Stack Web Development',
  'Automation Testing',
  'SEO Course',
  'Software Testing Training - Copy'


  8
  23
  23
  
  54